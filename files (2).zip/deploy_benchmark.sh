#!/usr/bin/env bash
# =============================================================================
# deploy_benchmark.sh — CyCentra 360 Benchmark Intelligence Engine (v2)
# =============================================================================
# Run from the repo root directory (where backend/ and portal/ live).
#
#   chmod +x benchmark-patch/deploy_benchmark.sh
#   ./benchmark-patch/deploy_benchmark.sh
# =============================================================================

set -e

REPO_ROOT="$(pwd)"
BACKEND="$REPO_ROOT/backend"
PORTAL="$REPO_ROOT/portal"
PATCH_DIR="$(cd "$(dirname "$0")" && pwd)"

echo ""
echo "══════════════════════════════════════════════════════════════"
echo "  CyCentra 360 — Benchmark Intelligence Engine deployment"
echo "══════════════════════════════════════════════════════════════"
echo ""

if [[ ! -f "$BACKEND/app.py" ]]; then echo "✗ backend/app.py not found."; exit 1; fi
if [[ ! -f "$PORTAL/src/App.jsx" ]]; then echo "✗ portal/src/App.jsx not found."; exit 1; fi

echo "── Step 1: Backend blueprint directory"
mkdir -p "$BACKEND/blueprints/benchmark"
touch    "$BACKEND/blueprints/benchmark/__init__.py"
echo "  ✓ blueprints/benchmark/__init__.py"

echo "── Step 2: Write routes.py  (PATCH_1 v2)"
cd "$BACKEND"
python3 "$PATCH_DIR/PATCH_1_backend_benchmark_v2.py"
cd "$REPO_ROOT"

echo "── Step 3: Write BenchmarkPage.jsx"
mkdir -p "$PORTAL/src/pages/benchmark"
cp "$PATCH_DIR/PATCH_2_frontend_BenchmarkPage.jsx" \
   "$PORTAL/src/pages/benchmark/BenchmarkPage.jsx"
echo "  ✓ BenchmarkPage.jsx"

echo "── Step 4: Apply wiring patches (app.py / App.jsx / navConfig.jsx)"
python3 "$PATCH_DIR/PATCH_3_wiring.py" "$REPO_ROOT"

echo "── Step 5: Restart backend"
if systemctl is-active --quiet cycentra-backend 2>/dev/null; then
    sudo systemctl restart cycentra-backend && echo "  ✓ restarted"
else
    echo "  ⚠ not running via systemctl — restart manually"
fi

echo "── Step 6: Rebuild portal"
cd "$PORTAL"
if [[ -f "package.json" ]]; then
    npm run build 2>&1 | tail -5 && echo "  ✓ built"
else
    echo "  ⚠ package.json not found — skipped"
fi

echo ""
echo "✅  Done.  Sidebar: SECURITY POSTURE → Posture Benchmark"
echo "   Config: /opt/cycentra/benchmark_config.json"
echo "   Scans:  SCANS_DIR/<uid>/  +  SCANS_DIR/scheduler/"
echo ""
