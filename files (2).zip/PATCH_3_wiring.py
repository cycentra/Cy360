"""
PATCH 3 of 3 — CyCentra 360 Benchmark Intelligence Engine
==========================================================
Three targeted str_replace patches. Apply them in order.
Each patch is clearly bounded — no other lines change.

PATCH 3A — backend/app.py      (register the blueprint, 2 lines)
PATCH 3B — portal/src/App.jsx  (import + render the page, 2 changes)
PATCH 3C — portal/src/sidebar/navConfig.jsx  (add nav item, 1 change)

All changes are additive — nothing is deleted or restructured.
"""

# ════════════════════════════════════════════════════════════════════════════════
# PATCH 3A — backend/app.py
# ════════════════════════════════════════════════════════════════════════════════
#
# Find this exact block in backend/app.py:
#
#   from blueprints.audit.routes       import audit_bp
#   from blueprints.sso.routes         import sso_bp
#
# Replace with:
#
#   from blueprints.audit.routes       import audit_bp
#   from blueprints.sso.routes         import sso_bp
#   from blueprints.benchmark.routes   import benchmark_bp
#
# ──────────────────────────────────────────────────────────────────────────────
# Then find this line in create_app():
#
#   for bp in (auth_bp, oidc_bp, rbac_bp, platform_bp, asm_bp, siem_bp, system_bp, backup_bp, scheduler_bp, marketplace_bp, audit_bp, sso_bp):
#
# Replace with:
#
#   for bp in (auth_bp, oidc_bp, rbac_bp, platform_bp, asm_bp, siem_bp, system_bp, backup_bp, scheduler_bp, marketplace_bp, audit_bp, sso_bp, benchmark_bp):
#
# ════════════════════════════════════════════════════════════════════════════════

PATCH_3A_FIND_1 = """\
from blueprints.audit.routes       import audit_bp
from blueprints.sso.routes         import sso_bp"""

PATCH_3A_REPLACE_1 = """\
from blueprints.audit.routes       import audit_bp
from blueprints.sso.routes         import sso_bp
from blueprints.benchmark.routes   import benchmark_bp"""

PATCH_3A_FIND_2 = """\
    for bp in (auth_bp, oidc_bp, rbac_bp, platform_bp, asm_bp, siem_bp, system_bp, backup_bp, scheduler_bp, marketplace_bp, audit_bp, sso_bp):"""

PATCH_3A_REPLACE_2 = """\
    for bp in (auth_bp, oidc_bp, rbac_bp, platform_bp, asm_bp, siem_bp, system_bp, backup_bp, scheduler_bp, marketplace_bp, audit_bp, sso_bp, benchmark_bp):"""


# ════════════════════════════════════════════════════════════════════════════════
# PATCH 3B — portal/src/App.jsx  (two str_replace operations)
# ════════════════════════════════════════════════════════════════════════════════

# 3B-1: Add the import alongside the other page imports.
#
# Find:
#   import { AuditTrailPage }   from './pages/audit/AuditTrailPage.jsx';
#
# Replace with:
#   import { AuditTrailPage }   from './pages/audit/AuditTrailPage.jsx';
#   import { BenchmarkPage }    from './pages/benchmark/BenchmarkPage.jsx';

PATCH_3B_FIND_1 = """\
import { AuditTrailPage }   from './pages/audit/AuditTrailPage.jsx';"""

PATCH_3B_REPLACE_1 = """\
import { AuditTrailPage }   from './pages/audit/AuditTrailPage.jsx';
import { BenchmarkPage }    from './pages/benchmark/BenchmarkPage.jsx';"""

# 3B-2: Add the route in the page-content render block.
#
# Find (the last two rendered pages before the closing tags):
#   {activeTab==="system-settings" && <SystemSettingsPage />}
#   {activeTab==="audit-trail"    && <AuditTrailPage />}
#
# Replace with:
#   {activeTab==="benchmark"       && <BenchmarkPage />}
#   {activeTab==="system-settings" && <SystemSettingsPage />}
#   {activeTab==="audit-trail"    && <AuditTrailPage />}

PATCH_3B_FIND_2 = """\
            {activeTab==="system-settings" && <SystemSettingsPage />}
            {activeTab==="audit-trail"    && <AuditTrailPage />}"""

PATCH_3B_REPLACE_2 = """\
            {activeTab==="benchmark"       && <BenchmarkPage />}
            {activeTab==="system-settings" && <SystemSettingsPage />}
            {activeTab==="audit-trail"    && <AuditTrailPage />}"""


# ════════════════════════════════════════════════════════════════════════════════
# PATCH 3C — portal/src/sidebar/navConfig.jsx
# ════════════════════════════════════════════════════════════════════════════════
#
# Add a new "SECURITY POSTURE" section containing the Benchmark item.
# It is inserted BEFORE the existing "ACTIONS" section so it appears naturally
# after the detection modules and before the administrative actions.
#
# Find:
#     {
#       section: "ACTIONS",
#       items: [
#         { id: "marketplace", label: "Marketplace",  icon: SvgMkt,   accent: "#4d9eff" },
#         { id: "audit-trail", label: "Audit Trail",  icon: SvgAudit, accent: "#b06eff" },
#       ],
#     },
#
# Replace with:
#     {
#       section: "SECURITY POSTURE",
#       items: [
#         { id: "benchmark", label: "Posture Benchmark", icon: SvgBench, accent: "#00e5a0" },
#       ],
#     },
#     {
#       section: "ACTIONS",
#       items: [
#         { id: "marketplace", label: "Marketplace",  icon: SvgMkt,   accent: "#4d9eff" },
#         { id: "audit-trail", label: "Audit Trail",  icon: SvgAudit, accent: "#b06eff" },
#       ],
#     },
#
# AND add the SvgBench icon constant alongside the other SVG icon constants.
# Find:
#   const SvgAI    = <svg ...
#
# Replace with:
#   const SvgBench = <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>;
#   const SvgAI    = <svg ...

PATCH_3C_FIND_ICON = """\
const SvgAI    = <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>;"""

PATCH_3C_REPLACE_ICON = """\
const SvgBench = <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>;
const SvgAI    = <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="12" r="3"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M4.93 4.93a10 10 0 0 0 0 14.14"/></svg>;"""

PATCH_3C_FIND_SECTION = """\
    {
      section: "ACTIONS",
      items: [
        { id: "marketplace", label: "Marketplace",  icon: SvgMkt,   accent: "#4d9eff" },
        { id: "audit-trail", label: "Audit Trail",  icon: SvgAudit, accent: "#b06eff" },
      ],
    },"""

PATCH_3C_REPLACE_SECTION = """\
    {
      section: "SECURITY POSTURE",
      items: [
        { id: "benchmark", label: "Posture Benchmark", icon: SvgBench, accent: "#00e5a0" },
      ],
    },
    {
      section: "ACTIONS",
      items: [
        { id: "marketplace", label: "Marketplace",  icon: SvgMkt,   accent: "#4d9eff" },
        { id: "audit-trail", label: "Audit Trail",  icon: SvgAudit, accent: "#b06eff" },
      ],
    },"""


# ════════════════════════════════════════════════════════════════════════════════
# APPLY SCRIPT — run this to apply all patches automatically
# ════════════════════════════════════════════════════════════════════════════════

def _str_replace(path: str, find: str, replace: str, label: str) -> bool:
    import pathlib
    p = pathlib.Path(path)
    if not p.exists():
        print(f"  ✗ {label}: file not found → {path}")
        return False
    content = p.read_text()
    if find not in content:
        print(f"  ✗ {label}: search string not found in {path}")
        print(f"    First 40 chars of search: {repr(find[:40])}")
        return False
    new_content = content.replace(find, replace, 1)
    p.write_text(new_content)
    print(f"  ✓ {label}")
    return True


def apply_all(repo_root: str = "."):
    """Apply all three patches. Run from the repo root."""
    import pathlib, sys
    root = pathlib.Path(repo_root)
    ok   = True

    print("\n── PATCH 3A: backend/app.py ──────────────────────────────────────")
    ok &= _str_replace(
        str(root / "backend/app.py"),
        PATCH_3A_FIND_1, PATCH_3A_REPLACE_1,
        "Add benchmark_bp import",
    )
    ok &= _str_replace(
        str(root / "backend/app.py"),
        PATCH_3A_FIND_2, PATCH_3A_REPLACE_2,
        "Register benchmark_bp in blueprint list",
    )

    print("\n── PATCH 3B: portal/src/App.jsx ──────────────────────────────────")
    ok &= _str_replace(
        str(root / "portal/src/App.jsx"),
        PATCH_3B_FIND_1, PATCH_3B_REPLACE_1,
        "Import BenchmarkPage",
    )
    ok &= _str_replace(
        str(root / "portal/src/App.jsx"),
        PATCH_3B_FIND_2, PATCH_3B_REPLACE_2,
        "Add benchmark tab render",
    )

    print("\n── PATCH 3C: portal/src/sidebar/navConfig.jsx ────────────────────")
    ok &= _str_replace(
        str(root / "portal/src/sidebar/navConfig.jsx"),
        PATCH_3C_FIND_ICON, PATCH_3C_REPLACE_ICON,
        "Add SvgBench icon constant",
    )
    ok &= _str_replace(
        str(root / "portal/src/sidebar/navConfig.jsx"),
        PATCH_3C_FIND_SECTION, PATCH_3C_REPLACE_SECTION,
        "Add SECURITY POSTURE nav section",
    )

    print()
    if ok:
        print("✅  All patches applied successfully.")
        print()
        print("NEXT STEPS:")
        print("  1. mkdir -p backend/blueprints/benchmark")
        print("  2. touch backend/blueprints/benchmark/__init__.py")
        print("  3. Apply PATCH_1 content → backend/blueprints/benchmark/routes.py")
        print("  4. Apply PATCH_2 content → portal/src/pages/benchmark/BenchmarkPage.jsx")
        print("  5. mkdir -p portal/src/pages/benchmark")
        print("  6. Restart backend: sudo systemctl restart cycentra-backend")
        print("  7. Rebuild frontend: cd portal && npm run build")
    else:
        print("❌  Some patches failed — check search strings above.")
        sys.exit(1)


if __name__ == "__main__":
    import sys
    repo = sys.argv[1] if len(sys.argv) > 1 else "."
    apply_all(repo)
