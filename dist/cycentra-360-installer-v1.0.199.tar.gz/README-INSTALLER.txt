CyCentra 360 Installer
======================

QUICK START
-----------
1. (Optional) Place your cycentra.lic in this directory.
   Without a license file, a 15-day demo is installed automatically.

2. Run the installer as root:
       sudo BASE_DOMAIN=your.domain.com ./cycentra-setup

Optional environment variables:
   BASE_DOMAIN      Your company's base domain (required)
   OAUTH_PROVIDER   google | microsoft | skip  (default: google)

After install:
   - Portal:      https://cy360.YOUR_DOMAIN
   - Backend API: https://cyasm.YOUR_DOMAIN
   - Edit /opt/cycentra/.env to change any config
   - systemctl restart cycentra-backend to apply changes
   - Upload or renew your license from Portal → System Settings → License

Support: support@cycentra.com
